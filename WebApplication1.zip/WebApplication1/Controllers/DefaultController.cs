﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication1.Controllers
{
    public class DefaultController : Controller
    {
        public IActionResult Index(int id)
        {
            return View();
        }

          public IActionResult Index1(int? id, int a, int b, int c)
          {
             

              return View();
          }
        
       /* public IActionResult login()
        {
            return View();
        }

        public IActionResult signup()
        {
            return View();
        }
       */
    }
}
